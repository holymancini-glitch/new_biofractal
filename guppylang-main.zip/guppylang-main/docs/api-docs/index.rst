Guppy Compiler API Documentation
================================

This is the API documentation for the Guppy compiler.

.. note::
   This page is designed for contributors to the Guppy compiler, not users of the language.
   See TODO for the language documentation.

.. autosummary::
   :toctree: generated
   :template: autosummary/module.rst
   :recursive:

   guppylang_internals


Indices and tables
~~~~~~~~~~~~~~~~~~

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
