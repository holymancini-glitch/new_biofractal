from __future__ import annotations
from typing import Dict, Any
from ..types import Candidate

class MetaCognition:
    def assess(self, focus: Candidate, self_metrics: Dict[str, float]) -> Dict[str, Any]:
        # combine candidate score with uncertainty
        conf = max(0.0, min(1.0, focus.score * (1.0 - self_metrics.get("uncertainty", 0.5))))
        return {"confidence": conf, "blindspots": ["unknowns"], "explanation": f"Selected {focus.key} with conf={conf:.2f}"}

    def should_abort(self, meta: Dict[str, Any], risk_threshold: float) -> bool:
        return meta["confidence"] < risk_threshold
