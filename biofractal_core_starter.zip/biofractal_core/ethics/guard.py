from __future__ import annotations
from typing import Dict, Any, List
from ..types import Action

class EthicsGuard:
    def allows(self, plan: List[Action], ask_before_act: bool = True) -> bool:
        # basic policy stub
        if ask_before_act:
            # in a real system, there would be a human/policy query here
            return True
        return True

    def screen(self, plan: List[Action]) -> List[str]:
        return ["checked_safety", "checked_privacy"]
