from __future__ import annotations
import time
from typing import Dict, Any
from ..types import Observation, Telemetry

class Sensor:
    def read(self) -> Observation:
        raise NotImplementedError

class SystemTelemetrySensor:
    def read(self) -> Telemetry:
        # TODO: replace mocks with real probes
        ts = time.time()
        return Telemetry(ts=ts, cpu=0.15, ram=0.32, latency_ms=12.3, policy_flags={"safe_mode": True})

class MockEnvSensor(Sensor):
    def read(self) -> Observation:
        return Observation(ts=time.time(), data={"env_event": "tick", "value": 1})
