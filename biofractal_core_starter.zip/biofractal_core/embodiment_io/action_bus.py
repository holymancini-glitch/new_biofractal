from __future__ import annotations
from typing import List
from ..types import Action, Outcome
from .actuators import Actuator

class ActionBus:
    def __init__(self, actuator: Actuator, shadow_default: bool = True):
        self.actuator = actuator
        self.shadow_default = shadow_default

    def dispatch(self, actions: List[Action]) -> List[Outcome]:
        outs = []
        for a in actions:
            if a.shadow is None:
                a.shadow = self.shadow_default
            outs.append(self.actuator.perform(a))
        return outs
