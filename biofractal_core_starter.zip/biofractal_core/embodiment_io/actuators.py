from __future__ import annotations
from ..types import Action, Outcome

class Actuator:
    def perform(self, action: Action) -> Outcome:
        raise NotImplementedError

class MockActuator(Actuator):
    def perform(self, action: Action) -> Outcome:
        # Shadow execution just validates
        if action.shadow:
            return Outcome(success=True, info={"mode": "shadow", "validated": True})
        # Real execution stub
        return Outcome(success=True, info={"mode": "real"})
