from __future__ import annotations
from typing import List
from ..types import Candidate

class GlobalWorkspace:
    def select(self, candidates: List[Candidate]) -> Candidate:
        # naive argmax
        return max(candidates, key=lambda c: c.score)
