from __future__ import annotations
from typing import List, Dict, Any
from ..types import Candidate, Action

class Planner:
    def solve(self, focus: Candidate, meta: Dict[str, Any]) -> List[Action]:
        # minimal plan: one action that logs status (shadow)
        return [Action(name="log_status", params={"focus": focus.key, "meta": meta}, shadow=True)]
