from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
from ..types import Observation

@dataclass
class WorldState:
    tick: int = 0
    facts: Dict[str, Any] = None

class WorldModel:
    def __init__(self):
        self.state = WorldState(tick=0, facts={})

    def update(self, obs: Observation) -> WorldState:
        self.state.tick += 1
        self.state.facts.update(obs.data)
        return self.state

    def propose_candidates(self) -> List[Dict[str, Any]]:
        # Return simple candidate intents based on state
        return [{"key": "monitor_env", "payload": {"tick": self.state.tick}, "reasons": ["periodic"]}]

    def what_if(self, actions: List[Dict[str, Any]]) -> Dict[str, Any]:
        # Stub risk/benefit projections
        return {"risk": 0.2, "benefit": 0.4}
