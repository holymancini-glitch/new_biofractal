from __future__ import annotations
from typing import Dict, Any

class Learner:
    def update(self, outcomes: Any, stats: Dict[str, float]) -> Dict[str, Any]:
        # learning stub
        return {"updates": 0, "mirror_gap": stats.get("mirror_gap", 0.0)}
