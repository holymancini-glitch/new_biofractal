from __future__ import annotations
from typing import Any, Dict, List
from ..types import Observation, Telemetry, Decision

class MemoryStore:
    def __init__(self):
        self.episodes: List[Dict[str, Any]] = []
        self.semantic: Dict[str, Any] = {}
        self.identity_versions: List[Dict[str, Any]] = []

    def write_episode(self, obs: Observation, tel: Telemetry, decision: Decision, rationale: Dict[str, Any]) -> None:
        self.episodes.append({
            "obs": obs.__dict__,
            "tel": tel.__dict__,
            "decision": {"selected": decision.selected.key, "meta": decision.meta},
            "rationale": rationale
        })
