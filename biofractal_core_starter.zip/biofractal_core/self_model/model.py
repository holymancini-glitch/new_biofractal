from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any
from ..types import Telemetry

@dataclass
class SelfState:
    competence: float
    uncertainty: float
    mirror_gap: float
    version: str = "0.1.0"

class SelfModel:
    def __init__(self):
        self.identity = {"persistent_id": "BF-CORE-001"}
        self.last_state = SelfState(competence=0.5, uncertainty=0.5, mirror_gap=0.0)

    def update(self, tel: Telemetry, history: Dict[str, Any]) -> SelfState:
        # simplistic heuristics for demo
        comp = max(0.0, 1.0 - (tel.cpu + tel.ram) / 2)
        unc  = min(1.0, tel.latency_ms / 100.0)
        mirror_gap = abs(history.get("social_feedback", 0.5) - comp)
        self.last_state = SelfState(competence=comp, uncertainty=unc, mirror_gap=mirror_gap)
        return self.last_state

    def describe(self) -> Dict[str, Any]:
        return {"id": self.identity["persistent_id"], "state": self.last_state.__dict__}
