from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

Timestamp = float

@dataclass
class Observation:
    ts: Timestamp
    data: Dict[str, Any]

@dataclass
class Telemetry:
    ts: Timestamp
    cpu: float
    ram: float
    latency_ms: float
    policy_flags: Dict[str, bool] = field(default_factory=dict)

@dataclass
class Candidate:
    key: str
    payload: Dict[str, Any]
    score: float
    reasons: List[str] = field(default_factory=list)

@dataclass
class Decision:
    selected: Candidate
    meta: Dict[str, Any]

@dataclass
class Action:
    name: str
    params: Dict[str, Any]
    shadow: bool = True  # shadow execution by default

@dataclass
class Outcome:
    success: bool
    info: Dict[str, Any]
