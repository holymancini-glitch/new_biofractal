from __future__ import annotations
from typing import List
from .config import CoreConfig
from .types import Candidate, Decision
from .embodiment_io.sensors import SystemTelemetrySensor, MockEnvSensor
from .embodiment_io.actuators import MockActuator
from .embodiment_io.action_bus import ActionBus
from .world_model.model import WorldModel
from .self_model.model import SelfModel
from .gwt_bus.bus import GlobalWorkspace
from .memory.store import MemoryStore
from .metacog.loop import MetaCognition
from .planner.planner import Planner
from .ethics.guard import EthicsGuard
from .learning.learner import Learner

class BioFractalAgent:
    def __init__(self, cfg: CoreConfig = CoreConfig()):
        self.cfg = cfg
        self.tel = SystemTelemetrySensor()
        self.env = MockEnvSensor()
        self.actuator = MockActuator()
        self.bus = ActionBus(self.actuator, shadow_default=cfg.enable_shadow_execution)

        self.world = WorldModel()
        self.selfm = SelfModel()
        self.gwt = GlobalWorkspace()
        self.memory = MemoryStore()
        self.meta = MetaCognition()
        self.planner = Planner()
        self.ethics = EthicsGuard()
        self.learner = Learner()
        self.history = {}

    def step(self):
        obs = self.env.read()
        tel = self.tel.read()

        W = self.world.update(obs)
        S = self.selfm.update(tel, self.history)

        # Candidates from world + self
        cands: List[Candidate] = []
        for c in self.world.propose_candidates():
            cands.append(Candidate(key=c["key"], payload=c.get("payload", {}), score=0.6, reasons=c.get("reasons", [])))
        # Self-candidate: self-check
        cands.append(Candidate(key="self_check", payload={"S": S.__dict__}, score=0.55, reasons=["maintenance"]))

        focus = self.gwt.select(cands)
        meta = self.meta.assess(focus, {"uncertainty": S.uncertainty})
        decision = Decision(selected=focus, meta=meta)

        if self.meta.should_abort(meta, self.cfg.risk_threshold):
            # abort/pause as safe default
            self.memory.write_episode(obs, tel, decision, {"explanation": "aborted_due_low_conf"})
            return {"status": "aborted"}

        plan = self.planner.solve(focus, meta)
        if not self.ethics.allows(plan, ask_before_act=self.cfg.ask_before_act):
            self.memory.write_episode(obs, tel, decision, {"explanation": "denied_by_ethics"})
            return {"status": "denied"}

        outcomes = self.bus.dispatch(plan)
        self.memory.write_episode(obs, tel, decision, {"explanation": meta["explanation"]})
        learn_stats = self.learner.update(outcomes, {"mirror_gap": S.mirror_gap})
        self.history["last_outcomes"] = outcomes
        self.history["learn_stats"] = learn_stats
        return {"status": "ok", "outcomes": [o.info for o in outcomes]}

if __name__ == "__main__":
    agent = BioFractalAgent()
    for _ in range(3):
        print(agent.step())
