from dataclasses import dataclass

@dataclass
class CoreConfig:
    enable_shadow_execution: bool = True
    max_candidates: int = 8
    risk_threshold: float = 0.4
    ask_before_act: bool = True
