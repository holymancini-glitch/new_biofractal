# Changelog

## [0.2.2](https://github.com/CQCL/selene/compare/selene-sim-v0.2.1...selene-sim-v0.2.2) (2025-08-20)


### Features

* random_advance ([#55](https://github.com/CQCL/selene/issues/55)) ([974b496](https://github.com/CQCL/selene/commit/974b496e3bc15b8ce155542d4f31e4e9fad245ed))
