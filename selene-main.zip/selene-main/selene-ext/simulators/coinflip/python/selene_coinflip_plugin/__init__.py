from .plugin import CoinflipPlugin

__all__ = ["CoinflipPlugin"]
